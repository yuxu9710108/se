#include "DataEngine.h"

CDataEngine::CDataEngine()
{
}

CDataEngine::CDataEngine(string str)
{
	m_str = str;
}

CDataEngine::~CDataEngine()
{
}
