#include "DatabaseEngine.h"

CDatabaseEngine::CDatabaseEngine(string str) : CDataEngine(str)
{
}

CDatabaseEngine::~CDatabaseEngine()
{
}
